<?php

declare(strict_types=1);

/**
 * Catatan kehadiran satu karyawan pada satu hari.
 *
 * Yang disimpan hanya fakta: jam masuk dan jam pulang. "Lengkap atau belum"
 * dan "berapa menit lembur" dihitung dari fakta itu, sehingga tidak ada dua
 * data yang bisa saling bertentangan.
 *
 * Satuan waktu: menit (int), bukan float jam, agar tidak ada galat pembulatan.
 */
final class Absensi
{
    public const JAM_PULANG_RESMI = '17:00';

    private int $karyawanId;
    private string $tanggal;
    private int $menitMasuk;
    private ?int $menitPulang = null;

    public function __construct(int $karyawanId, string $tanggal, string $jamMasuk)
    {
        if ($karyawanId < 1) {
            throw new InvalidArgumentException("ID karyawan harus positif, diterima: $karyawanId.");
        }
        $this->karyawanId = $karyawanId;
        $this->tanggal = Waktu::tanggal($tanggal);
        $this->menitMasuk = Waktu::jamKeMenit($jamMasuk);
    }

    // ---- Getter ----

    public function getKaryawanId(): int
    {
        return $this->karyawanId;
    }

    public function getTanggal(): string
    {
        return $this->tanggal;
    }

    public function getBulan(): string
    {
        return substr($this->tanggal, 0, 7);
    }

    public function getJamMasuk(): string
    {
        return Waktu::menitKeJam($this->menitMasuk);
    }

    public function getJamPulang(): ?string
    {
        return $this->menitPulang === null ? null : Waktu::menitKeJam($this->menitPulang);
    }

    /** Turunan, bukan state: lengkap = jam pulang sudah tercatat. */
    public function isLengkap(): bool
    {
        return $this->menitPulang !== null;
    }

    // ---- Method aksi ----

    public function catatPulang(string $jamPulang): void
    {
        if ($this->menitPulang !== null) {
            throw new DomainException(
                "Absen pulang {$this->tanggal} sudah tercatat pukul " . $this->getJamPulang() . '.'
            );
        }
        $menit = Waktu::jamKeMenit($jamPulang);
        if ($menit <= $this->menitMasuk) {
            throw new InvalidArgumentException(
                "Jam pulang ($jamPulang) harus setelah jam masuk (" . $this->getJamMasuk() . ').'
            );
        }
        $this->menitPulang = $menit;
    }

    public function hitungMenitKerja(): int
    {
        $this->pastikanLengkap();
        return $this->menitPulang - $this->menitMasuk;
    }

    /** Lembur = menit kerja setelah 17:00 (atau sejak jam masuk bila masuknya sudah lewat 17:00). */
    public function hitungMenitLembur(): int
    {
        $this->pastikanLengkap();
        $mulai = max($this->menitMasuk, Waktu::jamKeMenit(self::JAM_PULANG_RESMI));
        return max(0, $this->menitPulang - $mulai);
    }

    // ---- Persistensi ----

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'karyawanId' => $this->karyawanId,
            'tanggal' => $this->tanggal,
            'jamMasuk' => $this->getJamMasuk(),
            'jamPulang' => $this->getJamPulang(),
        ];
    }

    /** @param array<string, mixed> $data */
    public static function dariArray(array $data): self
    {
        $a = new self(
            (int) ($data['karyawanId'] ?? 0),
            (string) ($data['tanggal'] ?? ''),
            (string) ($data['jamMasuk'] ?? '')
        );
        if (isset($data['jamPulang'])) {
            $a->catatPulang((string) $data['jamPulang']);
        }
        return $a;
    }

    private function pastikanLengkap(): void
    {
        if ($this->menitPulang === null) {
            throw new DomainException("Absensi {$this->tanggal} belum lengkap: jam pulang belum dicatat.");
        }
    }
}
