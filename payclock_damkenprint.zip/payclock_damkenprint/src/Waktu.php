<?php

declare(strict_types=1);

/**
 * Helper parsing dan format waktu. Tanpa state, semua method statis.
 *
 * Domain tidak pernah memanggil date()/time() sendiri: waktu selalu dikirim
 * dari luar sebagai string, sehingga perilaku objek bisa diuji dengan
 * nilai yang pasti.
 */
final class Waktu
{
    /** Validasi 'YYYY-MM-DD' (menolak tanggal yang tidak ada, mis. 2026-02-30). */
    public static function tanggal(string $nilai): string
    {
        $dt = DateTimeImmutable::createFromFormat('!Y-m-d', $nilai);
        $err = DateTimeImmutable::getLastErrors();
        $bermasalah = $err !== false && ($err['warning_count'] > 0 || $err['error_count'] > 0);

        if ($dt === false || $bermasalah || $dt->format('Y-m-d') !== $nilai) {
            throw new InvalidArgumentException("Tanggal tidak valid: '$nilai' (format YYYY-MM-DD).");
        }
        return $nilai;
    }

    /** Validasi 'YYYY-MM'. */
    public static function bulan(string $nilai): string
    {
        if (!preg_match('/^\d{4}-(0[1-9]|1[0-2])$/', $nilai)) {
            throw new InvalidArgumentException("Bulan tidak valid: '$nilai' (format YYYY-MM).");
        }
        return $nilai;
    }

    public static function bulanDariTanggal(string $tanggal): string
    {
        return substr(self::tanggal($tanggal), 0, 7);
    }

    /** 'HH:MM' -> menit sejak 00:00. */
    public static function jamKeMenit(string $jam): int
    {
        if (!preg_match('/^([01]\d|2[0-3]):([0-5]\d)$/', $jam, $m)) {
            throw new InvalidArgumentException("Jam tidak valid: '$jam' (format HH:MM, 00:00-23:59).");
        }
        return ((int) $m[1]) * 60 + (int) $m[2];
    }

    public static function menitKeJam(int $menit): string
    {
        return sprintf('%02d:%02d', intdiv($menit, 60), $menit % 60);
    }

    public static function durasi(int $menit): string
    {
        return intdiv($menit, 60) . ' jam ' . ($menit % 60) . ' menit';
    }

    public static function rupiah(int $nilai): string
    {
        return 'Rp' . number_format($nilai, 0, ',', '.');
    }
}
