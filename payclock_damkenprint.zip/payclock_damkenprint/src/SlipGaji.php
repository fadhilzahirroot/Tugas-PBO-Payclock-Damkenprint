<?php

declare(strict_types=1);

/**
 * Slip gaji satu karyawan untuk satu bulan.
 *
 * Siklus hidup: draft -> dibayar (satu arah). Slip menyimpan snapshot gaji
 * pokok saat dihitung, jadi perubahan gaji pokok di bulan berikutnya tidak
 * mengubah slip lama. Setelah dibayar, slip tidak bisa dihitung ulang.
 *
 * Dibuat lewat SlipGaji::buat() atau SlipGaji::dariArray(); constructor
 * private agar tidak ada slip "setengah jadi".
 */
final class SlipGaji
{
    public const TARIF_LEMBUR_PER_JAM = 50_000;

    private const DRAFT = 'draft';
    private const DIBAYAR = 'dibayar';

    private int $karyawanId;
    private string $bulan;
    private int $gajiPokok = 0;
    private int $totalMenitKerja = 0;
    private int $totalMenitLembur = 0;
    private int $bonusLembur = 0;
    private int $totalGaji = 0;
    private string $status = self::DRAFT;

    private function __construct(int $karyawanId, string $bulan)
    {
        $this->karyawanId = $karyawanId;
        $this->bulan = $bulan;
    }

    /**
     * @param Absensi[] $daftarAbsensi semua absensi karyawan itu pada bulan tersebut
     */
    public static function buat(Karyawan $karyawan, string $bulan, array $daftarAbsensi): self
    {
        $slip = new self($karyawan->getId(), Waktu::bulan($bulan));
        $slip->hitung($karyawan, $daftarAbsensi);
        return $slip;
    }

    // ---- Getter ----

    public function getKaryawanId(): int
    {
        return $this->karyawanId;
    }

    public function getBulan(): string
    {
        return $this->bulan;
    }

    public function getGajiPokok(): int
    {
        return $this->gajiPokok;
    }

    public function getTotalMenitKerja(): int
    {
        return $this->totalMenitKerja;
    }

    public function getTotalMenitLembur(): int
    {
        return $this->totalMenitLembur;
    }

    public function getBonusLembur(): int
    {
        return $this->bonusLembur;
    }

    public function getTotalGaji(): int
    {
        return $this->totalGaji;
    }

    public function getStatus(): string
    {
        return $this->status;
    }

    public function isDibayar(): bool
    {
        return $this->status === self::DIBAYAR;
    }

    // ---- Method aksi ----

    /**
     * Hitung (ulang) slip yang masih draft. Semua pemeriksaan dilakukan lebih
     * dulu; state baru berubah jika semuanya lolos, sehingga kegagalan tidak
     * meninggalkan slip setengah terhitung.
     *
     * @param Absensi[] $daftarAbsensi
     */
    public function hitung(Karyawan $karyawan, array $daftarAbsensi): void
    {
        if ($this->isDibayar()) {
            throw new DomainException("Slip {$this->bulan} sudah dibayar dan tidak boleh dihitung ulang.");
        }
        if ($karyawan->getId() !== $this->karyawanId) {
            throw new InvalidArgumentException('Karyawan tidak sesuai dengan pemilik slip ini.');
        }
        if (!$karyawan->isAktif()) {
            throw new DomainException("{$karyawan->getNama()} nonaktif; slip tidak diproses.");
        }

        $menitKerja = 0;
        $menitLembur = 0;
        $belumPulang = [];
        $sudahDilihat = [];

        foreach ($daftarAbsensi as $absensi) {
            if (!$absensi instanceof Absensi) {
                throw new InvalidArgumentException('Daftar absensi hanya boleh berisi objek Absensi.');
            }
            if ($absensi->getKaryawanId() !== $this->karyawanId || $absensi->getBulan() !== $this->bulan) {
                throw new InvalidArgumentException(
                    "Absensi {$absensi->getTanggal()} bukan milik karyawan/bulan slip ini."
                );
            }
            if (isset($sudahDilihat[$absensi->getTanggal()])) {
                throw new InvalidArgumentException("Absensi ganda pada {$absensi->getTanggal()}.");
            }
            $sudahDilihat[$absensi->getTanggal()] = true;

            if (!$absensi->isLengkap()) {
                $belumPulang[] = $absensi->getTanggal();
                continue;
            }
            $menitKerja += $absensi->hitungMenitKerja();
            $menitLembur += $absensi->hitungMenitLembur();
        }

        if ($belumPulang !== []) {
            throw new DomainException(
                'Absensi belum lengkap (belum pulang): ' . implode(', ', $belumPulang)
                . '. Lengkapi dulu sebelum gaji dihitung.'
            );
        }

        // Semua valid: baru ubah state. Bonus dibulatkan ke bawah ke rupiah penuh.
        $bonus = intdiv($menitLembur * self::TARIF_LEMBUR_PER_JAM, 60);
        $this->gajiPokok = $karyawan->getGajiPokok();
        $this->totalMenitKerja = $menitKerja;
        $this->totalMenitLembur = $menitLembur;
        $this->bonusLembur = $bonus;
        $this->totalGaji = $this->gajiPokok + $bonus;
    }

    public function tandaiDibayar(): void
    {
        if ($this->isDibayar()) {
            throw new DomainException("Slip {$this->bulan} sudah dibayar; tidak boleh dibayar dua kali.");
        }
        $this->status = self::DIBAYAR;
    }

    // ---- Persistensi ----

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'karyawanId' => $this->karyawanId,
            'bulan' => $this->bulan,
            'gajiPokok' => $this->gajiPokok,
            'totalMenitKerja' => $this->totalMenitKerja,
            'totalMenitLembur' => $this->totalMenitLembur,
            'bonusLembur' => $this->bonusLembur,
            'totalGaji' => $this->totalGaji,
            'status' => $this->status,
        ];
    }

    /** @param array<string, mixed> $data */
    public static function dariArray(array $data): self
    {
        $slip = new self((int) ($data['karyawanId'] ?? 0), Waktu::bulan((string) ($data['bulan'] ?? '')));
        $status = (string) ($data['status'] ?? '');
        if (!in_array($status, [self::DRAFT, self::DIBAYAR], true)) {
            throw new InvalidArgumentException("Status slip tidak dikenal: '$status'.");
        }
        $slip->gajiPokok = (int) ($data['gajiPokok'] ?? 0);
        $slip->totalMenitKerja = (int) ($data['totalMenitKerja'] ?? 0);
        $slip->totalMenitLembur = (int) ($data['totalMenitLembur'] ?? 0);
        $slip->bonusLembur = (int) ($data['bonusLembur'] ?? 0);
        $slip->totalGaji = (int) ($data['totalGaji'] ?? 0);
        $slip->status = $status;

        if ($slip->karyawanId < 1 || $slip->totalGaji !== $slip->gajiPokok + $slip->bonusLembur) {
            throw new InvalidArgumentException('Data slip tidak konsisten (totalGaji != gajiPokok + bonusLembur).');
        }
        return $slip;
    }
}
