<?php

declare(strict_types=1);

/**
 * Karyawan Damken Print.
 *
 * Tanggung jawab: menyimpan identitas dan gaji pokok yang berlaku.
 * Semua state private; gaji pokok dan status hanya berubah lewat
 * method yang memvalidasi.
 */
final class Karyawan
{
    /** Batas atas wajar untuk menangkap salah ketik (mis. kelebihan nol). */
    public const GAJI_POKOK_MAKS = 50_000_000;

    private const NAMA_MIN = 2;
    private const NAMA_MAKS = 60;

    private int $id;
    private string $nama;
    private int $gajiPokok;
    private bool $aktif = true;

    public function __construct(int $id, string $nama, int $gajiPokok)
    {
        if ($id < 1) {
            throw new InvalidArgumentException("ID karyawan harus positif, diterima: $id.");
        }
        $this->id = $id;
        $this->nama = self::validasiNama($nama);
        $this->gajiPokok = self::validasiGajiPokok($gajiPokok);
    }

    // ---- Getter: hanya yang memang dibutuhkan pihak luar ----

    public function getId(): int
    {
        return $this->id;
    }

    public function getNama(): string
    {
        return $this->nama;
    }

    public function getGajiPokok(): int
    {
        return $this->gajiPokok;
    }

    public function isAktif(): bool
    {
        return $this->aktif;
    }

    // ---- Method aksi ----

    public function ubahGajiPokok(int $baru): void
    {
        $this->gajiPokok = self::validasiGajiPokok($baru);
    }

    public function aktifkan(): void
    {
        if ($this->aktif) {
            throw new DomainException("{$this->nama} sudah berstatus aktif.");
        }
        $this->aktif = true;
    }

    public function nonaktifkan(): void
    {
        if (!$this->aktif) {
            throw new DomainException("{$this->nama} sudah berstatus nonaktif.");
        }
        $this->aktif = false;
    }

    // ---- Persistensi: objek sendiri yang tahu cara menyajikan state-nya ----

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'nama' => $this->nama,
            'gajiPokok' => $this->gajiPokok,
            'aktif' => $this->aktif,
        ];
    }

    /** @param array<string, mixed> $data */
    public static function dariArray(array $data): self
    {
        $k = new self((int) ($data['id'] ?? 0), (string) ($data['nama'] ?? ''), (int) ($data['gajiPokok'] ?? 0));
        if (($data['aktif'] ?? true) === false) {
            $k->nonaktifkan();
        }
        return $k;
    }

    // ---- Validasi (satu pintu, dipakai constructor dan setter) ----

    private static function validasiNama(string $nama): string
    {
        $nama = trim($nama);
        $panjang = mb_strlen($nama);
        if ($panjang < self::NAMA_MIN || $panjang > self::NAMA_MAKS) {
            throw new InvalidArgumentException(
                'Nama harus ' . self::NAMA_MIN . '-' . self::NAMA_MAKS . " karakter, diterima: $panjang."
            );
        }
        return $nama;
    }

    private static function validasiGajiPokok(int $nilai): int
    {
        if ($nilai <= 0 || $nilai > self::GAJI_POKOK_MAKS) {
            throw new InvalidArgumentException(
                'Gaji pokok harus lebih dari 0 dan maksimal ' . Waktu::rupiah(self::GAJI_POKOK_MAKS)
                . ', diterima: ' . Waktu::rupiah($nilai) . '.'
            );
        }
        return $nilai;
    }
}
