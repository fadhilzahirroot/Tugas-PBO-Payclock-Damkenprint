<?php

declare(strict_types=1);

/**
 * Menyimpan dan memuat PayClock ke file JSON. Penulisan atomik (tulis file
 * sementara lalu rename) agar file tidak rusak jika proses terhenti.
 */
final class Penyimpanan
{
    private string $path;

    public function __construct(string $path)
    {
        $this->path = $path;
    }

    public function muat(): PayClock
    {
        if (!is_file($this->path)) {
            return new PayClock();
        }
        $isi = file_get_contents($this->path);
        if ($isi === false) {
            throw new RuntimeException("Gagal membaca {$this->path}.");
        }
        try {
            $data = json_decode($isi, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException $e) {
            throw new RuntimeException("File data {$this->path} rusak: {$e->getMessage()}");
        }
        return PayClock::dariArray((array) $data);
    }

    public function simpan(PayClock $app): void
    {
        $folder = dirname($this->path);
        if (!is_dir($folder) && !mkdir($folder, 0775, true) && !is_dir($folder)) {
            throw new RuntimeException("Gagal membuat folder $folder.");
        }
        $json = json_encode($app->toArray(), JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);
        $sementara = $this->path . '.tmp';
        if (file_put_contents($sementara, $json) === false || !rename($sementara, $this->path)) {
            throw new RuntimeException("Gagal menyimpan data ke {$this->path}.");
        }
    }
}
