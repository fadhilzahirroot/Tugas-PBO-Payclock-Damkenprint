<?php

declare(strict_types=1);

/**
 * Pintu masuk aplikasi: memegang daftar Karyawan, Absensi, dan SlipGaji, serta
 * menegakkan aturan yang melibatkan banyak objek (satu absen per hari, satu
 * slip per bulan, bulan yang sudah dibayar terkunci).
 *
 * Aturan satu objek ada di objeknya sendiri; aturan lintas objek ada di sini,
 * karena hanya pemilik daftar yang bisa memeriksanya.
 */
final class PayClock
{
    private int $nextId = 1;

    /** @var array<int, Karyawan> */
    private array $karyawan = [];

    /** @var array<string, Absensi> kunci "idKaryawan|YYYY-MM-DD" */
    private array $absensi = [];

    /** @var array<string, SlipGaji> kunci "idKaryawan|YYYY-MM" */
    private array $slip = [];

    // ---- Karyawan (FR2) ----

    public function tambahKaryawan(string $nama, int $gajiPokok): Karyawan
    {
        $k = new Karyawan($this->nextId, $nama, $gajiPokok);
        $this->karyawan[$k->getId()] = $k;
        $this->nextId++;
        return $k;
    }

    public function cariKaryawan(int $id): Karyawan
    {
        return $this->karyawan[$id] ?? throw new OutOfBoundsException("Karyawan dengan ID $id tidak ditemukan.");
    }

    /** @return Karyawan[] */
    public function daftarKaryawan(): array
    {
        return array_values($this->karyawan);
    }

    // ---- Absensi (FR1, FR6) ----

    public function absenMasuk(int $karyawanId, string $tanggal, string $jamMasuk): void
    {
        $k = $this->cariKaryawan($karyawanId);
        if (!$k->isAktif()) {
            throw new DomainException("{$k->getNama()} nonaktif; tidak bisa absen.");
        }
        $absensi = new Absensi($karyawanId, $tanggal, $jamMasuk); // validasi tanggal/jam
        $this->pastikanBulanTerbuka($karyawanId, $absensi->getBulan());

        $kunci = self::kunciHari($karyawanId, $absensi->getTanggal());
        if (isset($this->absensi[$kunci])) {
            throw new DomainException(
                "{$k->getNama()} sudah absen masuk pada {$absensi->getTanggal()}."
            );
        }
        $this->absensi[$kunci] = $absensi;
    }

    /** Dipakai karyawan (absen pulang) maupun pemilik (melengkapi absensi yang kosong). */
    public function absenPulang(int $karyawanId, string $tanggal, string $jamPulang): void
    {
        $this->cariKaryawan($karyawanId);
        $tanggal = Waktu::tanggal($tanggal);
        $this->pastikanBulanTerbuka($karyawanId, Waktu::bulanDariTanggal($tanggal));

        $absensi = $this->absensi[self::kunciHari($karyawanId, $tanggal)]
            ?? throw new DomainException("Belum ada absen masuk pada $tanggal; tidak bisa absen pulang.");
        $absensi->catatPulang($jamPulang);
    }

    /**
     * Salinan (clone) absensi satu bulan, urut tanggal. Salinan dipakai agar
     * pemanggil tidak bisa mengubah catatan asli tanpa melewati service ini.
     *
     * @return Absensi[]
     */
    public function absensiBulan(int $karyawanId, string $bulan): array
    {
        $this->cariKaryawan($karyawanId);
        $bulan = Waktu::bulan($bulan);

        $hasil = [];
        foreach ($this->absensi as $a) {
            if ($a->getKaryawanId() === $karyawanId && $a->getBulan() === $bulan) {
                $hasil[] = clone $a;
            }
        }
        usort($hasil, static fn (Absensi $x, Absensi $y) => strcmp($x->getTanggal(), $y->getTanggal()));
        return $hasil;
    }

    /**
     * Rekap kehadiran (FR3, FR8). Jam kerja hanya untuk rekap, bukan rumus gaji.
     *
     * @return array{hariHadir:int, menitKerja:int, menitLembur:int, belumPulang:string[]}
     */
    public function rekapBulan(int $karyawanId, string $bulan): array
    {
        $rekap = ['hariHadir' => 0, 'menitKerja' => 0, 'menitLembur' => 0, 'belumPulang' => []];
        foreach ($this->absensiBulan($karyawanId, $bulan) as $a) {
            $rekap['hariHadir']++;
            if (!$a->isLengkap()) {
                $rekap['belumPulang'][] = $a->getTanggal();
                continue;
            }
            $rekap['menitKerja'] += $a->hitungMenitKerja();
            $rekap['menitLembur'] += $a->hitungMenitLembur();
        }
        return $rekap;
    }

    // ---- Gaji (FR4, FR5, FR7) ----

    /**
     * Proses gaji semua karyawan aktif. Satu karyawan gagal (mis. absensi belum
     * lengkap) tidak menghentikan karyawan lain.
     *
     * @return list<array{karyawan:Karyawan, hasil:string, slip:?SlipGaji, pesan:string}>
     */
    public function prosesGajiBulanan(string $bulan): array
    {
        $bulan = Waktu::bulan($bulan);
        $laporan = [];

        foreach ($this->karyawan as $k) {
            if (!$k->isAktif()) {
                continue;
            }
            $kunci = self::kunciBulan($k->getId(), $bulan);
            $slipAda = $this->slip[$kunci] ?? null;

            if ($slipAda !== null && $slipAda->isDibayar()) {
                $laporan[] = ['karyawan' => $k, 'hasil' => 'dilewati', 'slip' => $slipAda,
                    'pesan' => 'Sudah dibayar, tidak diproses ulang.'];
                continue;
            }

            try {
                $absensi = $this->absensiBulan($k->getId(), $bulan);
                if ($slipAda === null) {
                    $this->slip[$kunci] = SlipGaji::buat($k, $bulan, $absensi);
                    $hasil = 'dibuat';
                } else {
                    $slipAda->hitung($k, $absensi);
                    $hasil = 'dihitung ulang';
                }
                $laporan[] = ['karyawan' => $k, 'hasil' => $hasil, 'slip' => $this->slip[$kunci], 'pesan' => ''];
            } catch (DomainException | InvalidArgumentException $e) {
                $laporan[] = ['karyawan' => $k, 'hasil' => 'gagal', 'slip' => $slipAda, 'pesan' => $e->getMessage()];
            }
        }
        return $laporan;
    }

    public function slipUntuk(int $karyawanId, string $bulan): SlipGaji
    {
        $this->cariKaryawan($karyawanId);
        $bulan = Waktu::bulan($bulan);
        return $this->slip[self::kunciBulan($karyawanId, $bulan)]
            ?? throw new DomainException("Belum ada slip gaji $bulan untuk karyawan ID $karyawanId. Proses gaji dulu.");
    }

    /** FR7: tandai gaji sebulan sudah dibayar (mencegah dibayar dua kali). */
    public function tandaiDibayar(int $karyawanId, string $bulan): void
    {
        $this->slipUntuk($karyawanId, $bulan)->tandaiDibayar();
    }

    // ---- Persistensi ----

    /** @return array<string, mixed> */
    public function toArray(): array
    {
        return [
            'nextId' => $this->nextId,
            'karyawan' => array_map(static fn (Karyawan $k) => $k->toArray(), array_values($this->karyawan)),
            'absensi' => array_map(static fn (Absensi $a) => $a->toArray(), array_values($this->absensi)),
            'slip' => array_map(static fn (SlipGaji $s) => $s->toArray(), array_values($this->slip)),
        ];
    }

    /** @param array<string, mixed> $data */
    public static function dariArray(array $data): self
    {
        $app = new self();
        foreach ((array) ($data['karyawan'] ?? []) as $d) {
            $k = Karyawan::dariArray((array) $d);
            $app->karyawan[$k->getId()] = $k;
        }
        foreach ((array) ($data['absensi'] ?? []) as $d) {
            $a = Absensi::dariArray((array) $d);
            $app->absensi[self::kunciHari($a->getKaryawanId(), $a->getTanggal())] = $a;
        }
        foreach ((array) ($data['slip'] ?? []) as $d) {
            $s = SlipGaji::dariArray((array) $d);
            $app->slip[self::kunciBulan($s->getKaryawanId(), $s->getBulan())] = $s;
        }
        $maksId = $app->karyawan === [] ? 0 : max(array_keys($app->karyawan));
        $app->nextId = max((int) ($data['nextId'] ?? 1), $maksId + 1);
        return $app;
    }

    // ---- Internal ----

    private function pastikanBulanTerbuka(int $karyawanId, string $bulan): void
    {
        $slip = $this->slip[self::kunciBulan($karyawanId, $bulan)] ?? null;
        if ($slip !== null && $slip->isDibayar()) {
            throw new DomainException("Gaji $bulan sudah dibayar; absensi bulan itu terkunci.");
        }
    }

    private static function kunciHari(int $karyawanId, string $tanggal): string
    {
        return $karyawanId . '|' . $tanggal;
    }

    private static function kunciBulan(int $karyawanId, string $bulan): string
    {
        return $karyawanId . '|' . $bulan;
    }
}
