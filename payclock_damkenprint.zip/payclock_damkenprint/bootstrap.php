<?php

declare(strict_types=1);

date_default_timezone_set('Asia/Jakarta');

foreach (['Waktu', 'Karyawan', 'Absensi', 'SlipGaji', 'PayClock', 'Penyimpanan'] as $kelas) {
    require_once __DIR__ . '/src/' . $kelas . '.php';
}
