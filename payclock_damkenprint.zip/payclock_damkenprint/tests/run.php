<?php

declare(strict_types=1);

require __DIR__ . '/../bootstrap.php';

$lulus = 0;
$gagal = 0;

function uji(string $nama, callable $fn): void
{
    global $lulus, $gagal;
    try {
        $fn();
        echo "[PASS] $nama\n";
        $lulus++;
    } catch (Throwable $e) {
        echo "[FAIL] $nama -> " . $e->getMessage() . "\n";
        $gagal++;
    }
}

/** Pastikan $fn melempar $kelas; kembalikan pesannya agar bisa diperiksa. */
function harapkanError(string $kelas, callable $fn, ?string $mengandung = null): string
{
    try {
        $fn();
    } catch (Throwable $e) {
        if (!($e instanceof $kelas)) {
            throw new Exception("Exception salah: diharapkan $kelas, dapat " . get_class($e) . ' (' . $e->getMessage() . ')');
        }
        if ($mengandung !== null && !str_contains($e->getMessage(), $mengandung)) {
            throw new Exception("Pesan '{$e->getMessage()}' tidak memuat '$mengandung'");
        }
        return $e->getMessage();
    }
    throw new Exception("Seharusnya melempar $kelas, tetapi tidak ada error.");
}

function samaDengan(mixed $diharapkan, mixed $aktual): void
{
    if ($diharapkan !== $aktual) {
        $d = var_export($diharapkan, true);
        $a = var_export($aktual, true);
        throw new Exception("Diharapkan $d, aktual $a");
    }
}

/** Absensi lengkap untuk satu hari. */
function hari(int $id, string $tgl, string $masuk, string $pulang): Absensi
{
    $a = new Absensi($id, $tgl, $masuk);
    $a->catatPulang($pulang);
    return $a;
}

echo "=== Absensi (FR1, FR3, FR4) ===\n";

uji('Normal: pulang 19:30 -> kerja 11,5 jam, lembur 150 menit', function () {
    $a = hari(1, '2026-10-05', '08:00', '19:30');
    samaDengan(690, $a->hitungMenitKerja());
    samaDengan(150, $a->hitungMenitLembur());
});

uji('Batas: pulang tepat 17:00 -> lembur 0; pulang 16:50 -> lembur 0', function () {
    samaDengan(0, hari(1, '2026-10-05', '08:00', '17:00')->hitungMenitLembur());
    samaDengan(0, hari(1, '2026-10-05', '08:00', '16:50')->hitungMenitLembur());
});

uji('Batas: masuk 18:00 pulang 20:00 -> seluruhnya lembur (120 menit)', function () {
    samaDengan(120, hari(1, '2026-10-05', '18:00', '20:00')->hitungMenitLembur());
});

uji('Input salah: jam pulang sebelum/sama dengan jam masuk ditolak, state tetap belum lengkap', function () {
    $a = new Absensi(1, '2026-10-05', '08:00');
    harapkanError(InvalidArgumentException::class, fn () => $a->catatPulang('07:59'), 'harus setelah jam masuk');
    harapkanError(InvalidArgumentException::class, fn () => $a->catatPulang('08:00'));
    samaDengan(false, $a->isLengkap());
});

uji('Input salah: format jam dan tanggal tidak valid ditolak', function () {
    foreach (['25:00', '8:5', '08:60', 'abc', ''] as $jam) {
        harapkanError(InvalidArgumentException::class, fn () => new Absensi(1, '2026-10-05', $jam));
    }
    foreach (['2026-02-30', '2026-13-01', '05-10-2026', ''] as $tgl) {
        harapkanError(InvalidArgumentException::class, fn () => new Absensi(1, $tgl, '08:00'));
    }
});

uji('Aturan: absen pulang dua kali ditolak', function () {
    $a = hari(1, '2026-10-05', '08:00', '17:00');
    harapkanError(DomainException::class, fn () => $a->catatPulang('18:00'), 'sudah tercatat');
    samaDengan('17:00', $a->getJamPulang());
});

uji('Aturan: menghitung absensi yang belum pulang ditolak (bukan dianggap 0 jam)', function () {
    $a = new Absensi(1, '2026-10-05', '08:00');
    harapkanError(DomainException::class, fn () => $a->hitungMenitKerja(), 'belum lengkap');
    harapkanError(DomainException::class, fn () => $a->hitungMenitLembur(), 'belum lengkap');
});

echo "\n=== Karyawan (FR2) ===\n";

uji('Normal: ubah gaji pokok dan nonaktifkan/aktifkan', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $k->ubahGajiPokok(3_500_000);
    samaDengan(3_500_000, $k->getGajiPokok());
    $k->nonaktifkan();
    samaDengan(false, $k->isAktif());
    $k->aktifkan();
    samaDengan(true, $k->isAktif());
});

uji('Input salah: gaji pokok 0, negatif, dan melebihi batas ditolak; nilai lama tetap', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    foreach ([0, -1, 50_000_001] as $nilai) {
        harapkanError(InvalidArgumentException::class, fn () => $k->ubahGajiPokok($nilai));
    }
    samaDengan(3_000_000, $k->getGajiPokok());
});

uji('Input salah: nama kosong/terlalu pendek ditolak di constructor', function () {
    harapkanError(InvalidArgumentException::class, fn () => new Karyawan(1, '   ', 3_000_000));
    harapkanError(InvalidArgumentException::class, fn () => new Karyawan(1, 'A', 3_000_000));
});

uji('Aturan: aktifkan karyawan yang sudah aktif ditolak (bukan diabaikan diam-diam)', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    harapkanError(DomainException::class, fn () => $k->aktifkan(), 'sudah berstatus aktif');
});

echo "\n=== SlipGaji (FR4, FR5, FR6, FR7) ===\n";

uji('Normal: gaji pokok 3.000.000 + lembur 90 menit = 3.075.000', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $slip = SlipGaji::buat($k, '2026-10', [
        hari(1, '2026-10-05', '08:00', '18:30'),
        hari(1, '2026-10-06', '08:00', '17:00'),
    ]);
    samaDengan(90, $slip->getTotalMenitLembur());
    samaDengan(75_000, $slip->getBonusLembur());
    samaDengan(3_075_000, $slip->getTotalGaji());
    samaDengan('draft', $slip->getStatus());
});

uji('Batas: lembur 20 menit -> bonus 16.666 (dibulatkan ke bawah, integer)', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $slip = SlipGaji::buat($k, '2026-10', [hari(1, '2026-10-05', '08:00', '17:20')]);
    samaDengan(16_666, $slip->getBonusLembur());
    samaDengan(3_016_666, $slip->getTotalGaji());
});

uji('Batas: tanpa absensi sama sekali -> gaji = gaji pokok', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    samaDengan(3_000_000, SlipGaji::buat($k, '2026-10', [])->getTotalGaji());
});

uji('Aturan: absensi belum pulang menolak perhitungan dan menyebut tanggalnya', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $pesan = harapkanError(DomainException::class, fn () => SlipGaji::buat($k, '2026-10', [
        hari(1, '2026-10-05', '08:00', '17:00'),
        new Absensi(1, '2026-10-06', '08:00'),
    ]), '2026-10-06');
    echo "       pesan: $pesan\n";
});

uji('Aturan: karyawan nonaktif tidak diproses', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $k->nonaktifkan();
    harapkanError(DomainException::class, fn () => SlipGaji::buat($k, '2026-10', []), 'nonaktif');
});

uji('Aturan: absensi bulan lain, milik orang lain, atau ganda ditolak', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    harapkanError(InvalidArgumentException::class, fn () => SlipGaji::buat($k, '2026-10', [hari(1, '2026-09-30', '08:00', '17:00')]));
    harapkanError(InvalidArgumentException::class, fn () => SlipGaji::buat($k, '2026-10', [hari(2, '2026-10-05', '08:00', '17:00')]));
    harapkanError(InvalidArgumentException::class, fn () => SlipGaji::buat($k, '2026-10', [
        hari(1, '2026-10-05', '08:00', '17:00'),
        hari(1, '2026-10-05', '08:00', '17:00'),
    ]), 'ganda');
});

uji('Aturan: slip dibayar tidak bisa dibayar dua kali maupun dihitung ulang', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $slip = SlipGaji::buat($k, '2026-10', []);
    $slip->tandaiDibayar();
    samaDengan(true, $slip->isDibayar());
    harapkanError(DomainException::class, fn () => $slip->tandaiDibayar(), 'dua kali');
    harapkanError(DomainException::class, fn () => $slip->hitung($k, []), 'tidak boleh dihitung ulang');
});

uji('Snapshot: ubah gaji pokok setelah slip dihitung tidak mengubah slip lama', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $slip = SlipGaji::buat($k, '2026-10', []);
    $k->ubahGajiPokok(4_000_000);
    samaDengan(3_000_000, $slip->getGajiPokok());
    samaDengan(3_000_000, $slip->getTotalGaji());
});

uji('Atomik: hitung ulang yang gagal tidak merusak hasil sebelumnya', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $slip = SlipGaji::buat($k, '2026-10', [hari(1, '2026-10-05', '08:00', '18:00')]);
    $sebelum = $slip->getTotalGaji();
    harapkanError(DomainException::class, fn () => $slip->hitung($k, [new Absensi(1, '2026-10-06', '08:00')]));
    samaDengan($sebelum, $slip->getTotalGaji());
});

echo "\n=== Akses langsung ke state (Praktikum 1 step 4) ===\n";

uji('Akses langsung: $karyawan->gajiPokok, $absensi->menitPulang, $slip->totalGaji ditolak', function () {
    $k = new Karyawan(1, 'Budi', 3_000_000);
    $a = new Absensi(1, '2026-10-05', '08:00');
    $s = SlipGaji::buat($k, '2026-10', []);
    harapkanError(Error::class, function () use ($k) {
        $k->gajiPokok = -5; // @phpstan-ignore-line
    }, 'private');
    harapkanError(Error::class, function () use ($a) {
        $a->menitPulang = 9999; // @phpstan-ignore-line
    }, 'private');
    harapkanError(Error::class, function () use ($s) {
        $s->totalGaji = 1; // @phpstan-ignore-line
    }, 'private');
    harapkanError(Error::class, fn () => new SlipGaji(1, '2026-10'), 'private'); // constructor private
    samaDengan(3_000_000, $k->getGajiPokok());
});

echo "\n=== PayClock: aturan lintas objek (FR5-FR8) ===\n";

function appContoh(): PayClock
{
    $app = new PayClock();
    $app->tambahKaryawan('Budi', 3_000_000);   // ID 1
    $app->tambahKaryawan('Siti', 3_200_000);   // ID 2
    return $app;
}

uji('Aturan: absen masuk dua kali pada hari yang sama ditolak', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    harapkanError(DomainException::class, fn () => $app->absenMasuk(1, '2026-10-05', '09:00'), 'sudah absen masuk');
});

uji('Aturan: absen pulang tanpa absen masuk, dan absen karyawan nonaktif, ditolak', function () {
    $app = appContoh();
    harapkanError(DomainException::class, fn () => $app->absenPulang(1, '2026-10-05', '17:00'), 'Belum ada absen masuk');
    $app->cariKaryawan(2)->nonaktifkan();
    harapkanError(DomainException::class, fn () => $app->absenMasuk(2, '2026-10-05', '08:00'), 'nonaktif');
    harapkanError(OutOfBoundsException::class, fn () => $app->absenMasuk(99, '2026-10-05', '08:00'));
});

uji('Normal: proses gaji menghasilkan slip, karyawan yang gagal tidak menghalangi yang lain', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    $app->absenPulang(1, '2026-10-05', '18:00');   // Budi lembur 60 menit
    $app->absenMasuk(2, '2026-10-05', '08:00');    // Siti belum pulang

    $lapor = $app->prosesGajiBulanan('2026-10');
    samaDengan('dibuat', $lapor[0]['hasil']);
    samaDengan(3_050_000, $lapor[0]['slip']->getTotalGaji());
    samaDengan('gagal', $lapor[1]['hasil']);
    samaDengan(true, str_contains($lapor[1]['pesan'], '2026-10-05'));
});

uji('Normal: setelah absensi dilengkapi, proses ulang menghitung ulang slip draft', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    $app->absenPulang(1, '2026-10-05', '17:00');
    $app->prosesGajiBulanan('2026-10');
    $app->absenMasuk(1, '2026-10-06', '08:00');
    $app->absenPulang(1, '2026-10-06', '19:00');   // +120 menit lembur
    $lapor = $app->prosesGajiBulanan('2026-10');
    samaDengan('dihitung ulang', $lapor[0]['hasil']);
    samaDengan(3_100_000, $app->slipUntuk(1, '2026-10')->getTotalGaji());
});

uji('Aturan: slip dibayar dilewati saat proses ulang, dan absensi bulan itu terkunci', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    $app->absenPulang(1, '2026-10-05', '17:00');
    $app->prosesGajiBulanan('2026-10');
    $app->tandaiDibayar(1, '2026-10');

    $lapor = $app->prosesGajiBulanan('2026-10');
    samaDengan('dilewati', $lapor[0]['hasil']);
    harapkanError(DomainException::class, fn () => $app->absenMasuk(1, '2026-10-20', '08:00'), 'terkunci');
    harapkanError(DomainException::class, fn () => $app->tandaiDibayar(1, '2026-10'), 'dua kali');
    $app->absenMasuk(1, '2026-11-02', '08:00'); // bulan lain tetap terbuka
});

uji('Aturan: slip yang belum diproses tidak bisa dibayar', function () {
    $app = appContoh();
    harapkanError(DomainException::class, fn () => $app->tandaiDibayar(1, '2026-10'), 'Belum ada slip');
});

uji('Enkapsulasi: absensiBulan() mengembalikan salinan, bukan objek asli', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    $salinan = $app->absensiBulan(1, '2026-10')[0];
    $salinan->catatPulang('17:00');           // mengubah salinan
    samaDengan(false, $app->absensiBulan(1, '2026-10')[0]->isLengkap()); // aslinya tetap
});

echo "\n=== Penyimpanan JSON ===\n";

uji('Roundtrip: simpan lalu muat menghasilkan data yang sama (termasuk slip dibayar)', function () {
    $app = appContoh();
    $app->absenMasuk(1, '2026-10-05', '08:00');
    $app->absenPulang(1, '2026-10-05', '18:15');
    $app->cariKaryawan(2)->nonaktifkan();
    $app->prosesGajiBulanan('2026-10');
    $app->tandaiDibayar(1, '2026-10');

    $path = sys_get_temp_dir() . '/payclock-uji-' . getmypid() . '.json';
    $simpan = new Penyimpanan($path);
    $simpan->simpan($app);
    $muat = $simpan->muat();
    @unlink($path);

    samaDengan($app->toArray(), $muat->toArray());
    samaDengan(true, $muat->slipUntuk(1, '2026-10')->isDibayar());
    samaDengan(false, $muat->cariKaryawan(2)->isAktif());
    $baru = $muat->tambahKaryawan('Rudi', 3_000_000);
    samaDengan(3, $baru->getId());            // nextId dipulihkan
});

uji('Input salah: file data rusak ditolak dengan pesan jelas', function () {
    $path = sys_get_temp_dir() . '/payclock-rusak-' . getmypid() . '.json';
    file_put_contents($path, '{bukan json');
    try {
        harapkanError(RuntimeException::class, fn () => (new Penyimpanan($path))->muat(), 'rusak');
    } finally {
        @unlink($path);
    }
});

echo "\nRingkasan: $lulus lulus, $gagal gagal\n";
exit($gagal === 0 ? 0 : 1);
